// // // // "use client"

// // // // import { useState, useEffect } from "react"
// // // // import { View, Text, StyleSheet, TouchableOpacity, ScrollView, SafeAreaView, ActivityIndicator } from "react-native"
// // // // import { getAuth, signOut } from "firebase/auth"
// // // // import { collection, getDocs, query, orderBy, limit } from "firebase/firestore"
// // // // import { db } from "../firebaseConfig"
// // // // import Feather from "react-native-vector-icons/Feather"

// // // // const Dashboard = ({ navigation }) => {
// // // //   const auth = getAuth()
// // // //   const [loading, setLoading] = useState(true)
// // // //   const [stats, setStats] = useState({
// // // //     totalProducts: 0,
// // // //     lowStock: 0,
// // // //     expiringItems: 0,
// // // //     totalSales: 0,
// // // //     totalCustomers: 0,
// // // //   })
// // // //   const [recentSales, setRecentSales] = useState([])
// // // //   const [menuVisible, setMenuVisible] = useState(false)

// // // //   useEffect(() => {
// // // //     fetchDashboardData()
// // // //   }, [])

// // // //   const fetchDashboardData = async () => {
// // // //     try {
// // // //       setLoading(true)

// // // //       // Fetch product stats
// // // //       const productsRef = collection(db, "products")
// // // //       const productsSnapshot = await getDocs(productsRef)
// // // //       const totalProducts = productsSnapshot.size

// // // //       // Count low stock items
// // // //       const lowStockItems = productsSnapshot.docs.filter((doc) => doc.data().quantity <= doc.data().reorderLevel).length

// // // //       // Count expiring items (within 90 days)
// // // //       const today = new Date()
// // // //       const ninetyDaysFromNow = new Date()
// // // //       ninetyDaysFromNow.setDate(today.getDate() + 90)

// // // //       const expiringItems = productsSnapshot.docs.filter((doc) => {
// // // //         const expiryDate = doc.data().expiryDate?.toDate()
// // // //         return expiryDate && expiryDate <= ninetyDaysFromNow
// // // //       }).length

// // // //       // Fetch customer count
// // // //       const customersRef = collection(db, "customers")
// // // //       const customersSnapshot = await getDocs(customersRef)
// // // //       const totalCustomers = customersSnapshot.size

// // // //       // Fetch sales data
// // // //       const salesRef = collection(db, "sales")
// // // //       const salesSnapshot = await getDocs(salesRef)

// // // //       // Calculate total sales
// // // //       let totalSalesAmount = 0
// // // //       salesSnapshot.docs.forEach((doc) => {
// // // //         totalSalesAmount += doc.data().totalAmount || 0
// // // //       })

// // // //       // Get recent sales
// // // //       const recentSalesQuery = query(collection(db, "sales"), orderBy("date", "desc"), limit(5))
// // // //       const recentSalesSnapshot = await getDocs(recentSalesQuery)
// // // //       const recentSalesData = recentSalesSnapshot.docs.map((doc) => ({
// // // //         id: doc.id,
// // // //         ...doc.data(),
// // // //         date: doc.data().date?.toDate() || new Date(),
// // // //       }))

// // // //       setStats({
// // // //         totalProducts,
// // // //         lowStock: lowStockItems,
// // // //         expiringItems,
// // // //         totalSales: totalSalesAmount,
// // // //         totalCustomers,
// // // //       })

// // // //       setRecentSales(recentSalesData)
// // // //       setLoading(false)
// // // //     } catch (error) {
// // // //       console.error("Error fetching dashboard data:", error)
// // // //       setLoading(false)
// // // //     }
// // // //   }

// // // //   const handleLogout = () => {
// // // //     signOut(auth)
// // // //       .then(() => {
// // // //         console.log("User logged out")
// // // //         navigation.replace("Login")
// // // //       })
// // // //       .catch((error) => {
// // // //         console.error("Logout failed:", error.message)
// // // //       })
// // // //   }

// // // //   const navigateTo = (screen) => {
// // // //     setMenuVisible(false)
// // // //     navigation.navigate(screen)
// // // //   }

// // // //   if (loading) {
// // // //     return (
// // // //       <View style={styles.loadingContainer}>
// // // //         <ActivityIndicator size="large" color="#2e7d32" />
// // // //         <Text style={styles.loadingText}>Loading dashboard...</Text>
// // // //       </View>
// // // //     )
// // // //   }

// // // //   return (
// // // //     <SafeAreaView style={styles.container}>
// // // //       <View style={styles.header}>
// // // //         <Text style={styles.headerTitle}>Rucha Medical</Text>
// // // //         <View style={styles.headerRight}>
// // // //           <TouchableOpacity style={styles.menuButton} onPress={() => setMenuVisible(!menuVisible)}>
// // // //             <Feather name="menu" size={24} color="#2e7d32" />
// // // //           </TouchableOpacity>
// // // //         </View>
// // // //       </View>

// // // //       {menuVisible && (
// // // //         <View style={styles.menuContainer}>
// // // //           <TouchableOpacity style={styles.menuItem} onPress={() => navigateTo("Inventory")}>
// // // //             <Feather name="package" size={20} color="#2e7d32" />
// // // //             <Text style={styles.menuText}>Inventory</Text>
// // // //           </TouchableOpacity>

// // // //           <TouchableOpacity style={styles.menuItem} onPress={() => navigateTo("Sales")}>
// // // //             <Feather name="trending-up" size={20} color="#2e7d32" />
// // // //             <Text style={styles.menuText}>Sales</Text>
// // // //           </TouchableOpacity>

// // // //           <TouchableOpacity style={styles.menuItem} onPress={() => navigateTo("Customers")}>
// // // //             <Feather name="users" size={20} color="#2e7d32" />
// // // //             <Text style={styles.menuText}>Customers</Text>
// // // //           </TouchableOpacity>

// // // //           <TouchableOpacity style={styles.menuItem} onPress={() => navigateTo("Prescriptions")}>
// // // //             <Feather name="file-text" size={20} color="#2e7d32" />
// // // //             <Text style={styles.menuText}>Prescriptions</Text>
// // // //           </TouchableOpacity>

// // // //           <TouchableOpacity style={styles.menuItem} onPress={() => navigateTo("Reports")}>
// // // //             <Feather name="trending-up" size={20} color="#2e7d32" />
// // // //             <Text style={styles.menuText}>Reports</Text>
// // // //           </TouchableOpacity>

// // // //           <TouchableOpacity style={styles.menuItem} onPress={handleLogout}>
// // // //             <Feather name="log-out" size={20} color="#d32f2f" />
// // // //             <Text style={[styles.menuText, { color: "#d32f2f" }]}>Logout</Text>
// // // //           </TouchableOpacity>
// // // //         </View>
// // // //       )}

// // // //       <ScrollView style={styles.scrollContainer}>
// // // //         <Text style={styles.sectionTitle}>Dashboard Overview</Text>

// // // //         <View style={styles.statsContainer}>
// // // //           <View style={styles.statCard}>
// // // //             <Text style={styles.statValue}>{stats.totalProducts}</Text>
// // // //             <Text style={styles.statLabel}>Total Products</Text>
// // // //           </View>

// // // //           <View style={styles.statCard}>
// // // //             <Text style={styles.statValue}>{stats.lowStock}</Text>
// // // //             <Text style={styles.statLabel}>Low Stock Items</Text>
// // // //           </View>

// // // //           <View style={styles.statCard}>
// // // //             <Text style={styles.statValue}>{stats.expiringItems}</Text>
// // // //             <Text style={styles.statLabel}>Expiring Soon</Text>
// // // //           </View>
// // // //         </View>

// // // //         <View style={styles.statsContainer}>
// // // //           <View style={styles.statCard}>
// // // //             <Text style={styles.statValue}>₹{stats.totalSales.toLocaleString()}</Text>
// // // //             <Text style={styles.statLabel}>Total Sales</Text>
// // // //           </View>

// // // //           <View style={styles.statCard}>
// // // //             <Text style={styles.statValue}>{stats.totalCustomers}</Text>
// // // //             <Text style={styles.statLabel}>Customers</Text>
// // // //           </View>
// // // //         </View>

// // // //         <View style={styles.alertsContainer}>
// // // //           {stats.lowStock > 0 && (
// // // //             <View style={styles.alertCard}>
// // // //               <Feather name="alert-circle" size={20} color="#ff9800" />

// // // //               <Text style={styles.alertText}>{stats.lowStock} products are low in stock</Text>
// // // //             </View>
// // // //           )}

// // // //           {stats.expiringItems > 0 && (
// // // //             <View style={styles.alertCard}>
// // // //               <Feather name="alert-circle" size={20} color="#ff9800" />

// // // //               <Text style={styles.alertText}>{stats.expiringItems} products are expiring soon</Text>
// // // //             </View>
// // // //           )}
// // // //         </View>

// // // //         <Text style={styles.sectionTitle}>Recent Sales</Text>

// // // //         {recentSales.length > 0 ? (
// // // //           <View style={styles.recentSalesContainer}>
// // // //             {recentSales.map((sale) => (
// // // //               <View key={sale.id} style={styles.saleItem}>
// // // //                 <View>
// // // //                   <Text style={styles.saleItemTitle}>Invoice #{sale.invoiceNumber || sale.id.substring(0, 6)}</Text>
// // // //                   <Text style={styles.saleItemDate}>{sale.date.toDateString()}</Text>
// // // //                 </View>
// // // //                 <Text style={styles.saleItemAmount}>₹{sale.totalAmount?.toLocaleString() || "0"}</Text>
// // // //               </View>
// // // //             ))}
// // // //           </View>
// // // //         ) : (
// // // //           <View style={styles.emptyStateContainer}>
// // // //             <Text style={styles.emptyStateText}>No recent sales</Text>
// // // //           </View>
// // // //         )}

// // // //         <View style={styles.actionButtonsContainer}>
// // // //           <TouchableOpacity style={styles.actionButton} onPress={() => navigation.navigate("NewSale")}>
// // // //             <Text style={styles.actionButtonText}>New Sale</Text>
// // // //           </TouchableOpacity>

// // // //           <TouchableOpacity style={styles.actionButton} onPress={() => navigation.navigate("AddProduct")}>
// // // //             <Text style={styles.actionButtonText}>Add Product</Text>
// // // //           </TouchableOpacity>
// // // //         </View>
// // // //       </ScrollView>
// // // //     </SafeAreaView>
// // // //   )
// // // // }

// // // // const styles = StyleSheet.create({
// // // //   container: {
// // // //     flex: 1,
// // // //     backgroundColor: "#f5f5f5",
// // // //   },
// // // //   loadingContainer: {
// // // //     flex: 1,
// // // //     justifyContent: "center",
// // // //     alignItems: "center",
// // // //     backgroundColor: "#f5f5f5",
// // // //   },
// // // //   loadingText: {
// // // //     marginTop: 10,
// // // //     fontSize: 16,
// // // //     color: "#2e7d32",
// // // //   },
// // // //   header: {
// // // //     flexDirection: "row",
// // // //     alignItems: "center",
// // // //     justifyContent: "space-between",
// // // //     paddingHorizontal: 16,
// // // //     paddingVertical: 12,
// // // //     backgroundColor: "#fff",
// // // //     borderBottomWidth: 1,
// // // //     borderBottomColor: "#e0e0e0",
// // // //   },
// // // //   headerTitle: {
// // // //     fontSize: 20,
// // // //     fontWeight: "bold",
// // // //     color: "#2e7d32",
// // // //   },
// // // //   headerRight: {
// // // //     flexDirection: "row",
// // // //     alignItems: "center",
// // // //   },
// // // //   menuButton: {
// // // //     padding: 8,
// // // //   },
// // // //   menuContainer: {
// // // //     position: "absolute",
// // // //     top: 60,
// // // //     right: 16,
// // // //     backgroundColor: "#fff",
// // // //     borderRadius: 8,
// // // //     padding: 8,
// // // //     zIndex: 1000,
// // // //     shadowColor: "#000",
// // // //     shadowOffset: { width: 0, height: 2 },
// // // //     shadowOpacity: 0.1,
// // // //     shadowRadius: 4,
// // // //     elevation: 3,
// // // //   },
// // // //   menuItem: {
// // // //     flexDirection: "row",
// // // //     alignItems: "center",
// // // //     paddingVertical: 12,
// // // //     paddingHorizontal: 16,
// // // //   },
// // // //   menuText: {
// // // //     marginLeft: 12,
// // // //     fontSize: 16,
// // // //     color: "#424242",
// // // //   },
// // // //   scrollContainer: {
// // // //     flex: 1,
// // // //     padding: 16,
// // // //   },
// // // //   sectionTitle: {
// // // //     fontSize: 18,
// // // //     fontWeight: "bold",
// // // //     color: "#424242",
// // // //     marginBottom: 16,
// // // //     marginTop: 8,
// // // //   },
// // // //   statsContainer: {
// // // //     flexDirection: "row",
// // // //     justifyContent: "space-between",
// // // //     marginBottom: 16,
// // // //   },
// // // //   statCard: {
// // // //     flex: 1,
// // // //     backgroundColor: "#fff",
// // // //     borderRadius: 8,
// // // //     padding: 16,
// // // //     marginHorizontal: 4,
// // // //     alignItems: "center",
// // // //     shadowColor: "#000",
// // // //     shadowOffset: { width: 0, height: 1 },
// // // //     shadowOpacity: 0.05,
// // // //     shadowRadius: 2,
// // // //     elevation: 2,
// // // //   },
// // // //   statValue: {
// // // //     fontSize: 20,
// // // //     fontWeight: "bold",
// // // //     color: "#2e7d32",
// // // //     marginBottom: 4,
// // // //   },
// // // //   statLabel: {
// // // //     fontSize: 14,
// // // //     color: "#616161",
// // // //     textAlign: "center",
// // // //   },
// // // //   alertsContainer: {
// // // //     marginBottom: 16,
// // // //   },
// // // //   alertCard: {
// // // //     flexDirection: "row",
// // // //     alignItems: "center",
// // // //     backgroundColor: "#fff3e0",
// // // //     borderRadius: 8,
// // // //     padding: 12,
// // // //     marginBottom: 8,
// // // //   },
// // // //   alertText: {
// // // //     marginLeft: 8,
// // // //     fontSize: 14,
// // // //     color: "#e65100",
// // // //   },
// // // //   recentSalesContainer: {
// // // //     backgroundColor: "#fff",
// // // //     borderRadius: 8,
// // // //     overflow: "hidden",
// // // //     marginBottom: 16,
// // // //   },
// // // //   saleItem: {
// // // //     flexDirection: "row",
// // // //     justifyContent: "space-between",
// // // //     alignItems: "center",
// // // //     paddingVertical: 12,
// // // //     paddingHorizontal: 16,
// // // //     borderBottomWidth: 1,
// // // //     borderBottomColor: "#f0f0f0",
// // // //   },
// // // //   saleItemTitle: {
// // // //     fontSize: 15,
// // // //     fontWeight: "500",
// // // //     color: "#424242",
// // // //   },
// // // //   saleItemDate: {
// // // //     fontSize: 13,
// // // //     color: "#757575",
// // // //     marginTop: 2,
// // // //   },
// // // //   saleItemAmount: {
// // // //     fontSize: 16,
// // // //     fontWeight: "bold",
// // // //     color: "#2e7d32",
// // // //   },
// // // //   emptyStateContainer: {
// // // //     backgroundColor: "#fff",
// // // //     borderRadius: 8,
// // // //     padding: 24,
// // // //     alignItems: "center",
// // // //     marginBottom: 16,
// // // //   },
// // // //   emptyStateText: {
// // // //     fontSize: 16,
// // // //     color: "#9e9e9e",
// // // //   },
// // // //   actionButtonsContainer: {
// // // //     flexDirection: "row",
// // // //     justifyContent: "space-between",
// // // //     marginBottom: 24,
// // // //   },
// // // //   actionButton: {
// // // //     flex: 1,
// // // //     backgroundColor: "#2e7d32",
// // // //     borderRadius: 8,
// // // //     paddingVertical: 12,
// // // //     alignItems: "center",
// // // //     marginHorizontal: 4,
// // // //   },
// // // //   actionButtonText: {
// // // //     color: "#fff",
// // // //     fontSize: 16,
// // // //     fontWeight: "500",
// // // //   },
// // // // })

// // // // export default Dashboard


// // // import React, { useState, useEffect } from 'react';
// // // import { View, Text, StyleSheet, TouchableOpacity, ScrollView, ActivityIndicator } from 'react-native';
// // // import { collection, getDocs, query, where, orderBy, limit } from 'firebase/firestore';
// // // import { db } from '../firebaseConfig';
// // // import Icon from 'react-native-vector-icons/MaterialIcons';

// // // const Dashboard = ({ navigation }) => {
// // //   const [loading, setLoading] = useState(true);
// // //   const [dashboardData, setDashboardData] = useState({
// // //     totalProducts: 0,
// // //     lowStockProducts: 0,
// // //     totalSales: 0,
// // //     recentSales: [],
// // //     expiringProducts: []
// // //   });

// // //   useEffect(() => {
// // //     const fetchDashboardData = async () => {
// // //       try {
// // //         setLoading(true);
        
// // //         // Get total products
// // //         const productsSnapshot = await getDocs(collection(db, 'products'));
// // //         const totalProducts = productsSnapshot.size;
        
// // //         // Get low stock products
// // //         const lowStockQuery = query(
// // //           collection(db, 'products'),
// // //           where('quantity', '<', 10)
// // //         );
// // //         const lowStockSnapshot = await getDocs(lowStockQuery);
// // //         const lowStockProducts = lowStockSnapshot.size;
        
// // //         // Get total sales
// // //         const salesSnapshot = await getDocs(collection(db, 'sales'));
// // //         let totalSales = 0;
// // //         salesSnapshot.forEach(doc => {
// // //           const saleData = doc.data();
// // //           totalSales += saleData.totalAmount || 0;
// // //         });
        
// // //         // Get recent sales
// // //         const recentSalesQuery = query(
// // //           collection(db, 'sales'),
// // //           orderBy('date', 'desc'),
// // //           limit(5)
// // //         );
// // //         const recentSalesSnapshot = await getDocs(recentSalesQuery);
// // //         const recentSales = recentSalesSnapshot.docs.map(doc => {
// // //           const data = doc.data();
// // //           // Safely handle date conversion
// // //           const date = data.date && typeof data.date.toDate === 'function' 
// // //             ? data.date.toDate() 
// // //             : new Date();
          
// // //           return {
// // //             id: doc.id,
// // //             ...data,
// // //             date: date
// // //           };
// // //         });
        
// // //         // Get expiring products
// // //         const today = new Date();
// // //         const threeMonthsLater = new Date();
// // //         threeMonthsLater.setMonth(today.getMonth() + 3);
        
// // //         const expiringProductsQuery = query(
// // //           collection(db, 'products'),
// // //           where('expiryDate', '<=', threeMonthsLater)
// // //         );
        
// // //         const expiringProductsSnapshot = await getDocs(expiringProductsQuery);
// // //         const expiringProducts = expiringProductsSnapshot.docs.map(doc => {
// // //           const data = doc.data();
// // //           // Safely handle date conversion
// // //           const expiryDate = data.expiryDate && typeof data.expiryDate.toDate === 'function'
// // //             ? data.expiryDate.toDate()
// // //             : null;
          
// // //           return {
// // //             id: doc.id,
// // //             ...data,
// // //             expiryDate: expiryDate
// // //           };
// // //         }).filter(product => product.expiryDate !== null);
        
// // //         setDashboardData({
// // //           totalProducts,
// // //           lowStockProducts,
// // //           totalSales,
// // //           recentSales,
// // //           expiringProducts
// // //         });
        
// // //       } catch (error) {
// // //         console.error("Error fetching dashboard data:", error);
// // //       } finally {
// // //         setLoading(false);
// // //       }
// // //     };

// // //     fetchDashboardData();
// // //   }, []);

// // //   const formatDate = (date) => {
// // //     if (!date) return 'N/A';
// // //     return `${date.getDate()}/${date.getMonth() + 1}/${date.getFullYear()}`;
// // //   };

// // //   const formatCurrency = (amount) => {
// // //     return `$${parseFloat(amount).toFixed(2)}`;
// // //   };

// // //   if (loading) {
// // //     return (
// // //       <View style={styles.loadingContainer}>
// // //         <ActivityIndicator size="large" color="#4CAF50" />
// // //         <Text style={styles.loadingText}>Loading dashboard...</Text>
// // //       </View>
// // //     );
// // //   }

// // //   return (
// // //     <View style={styles.container}>
// // //       <View style={styles.header}>
// // //         <Text style={styles.headerTitle}>Dashboard</Text>
// // //         <TouchableOpacity onPress={() => navigation.toggleDrawer()}>
// // //           <Icon name="menu" size={24} color="#fff" />
// // //         </TouchableOpacity>
// // //       </View>
      
// // //       <ScrollView style={styles.content}>
// // //         <View style={styles.statsContainer}>
// // //           <TouchableOpacity 
// // //             style={styles.statCard} 
// // //             onPress={() => navigation.navigate('Inventory')}
// // //           >
// // //             <Text style={styles.statValue}>{dashboardData.totalProducts}</Text>
// // //             <Text style={styles.statLabel}>Total Products</Text>
// // //           </TouchableOpacity>
          
// // //           <TouchableOpacity 
// // //             style={[styles.statCard, styles.warningCard]} 
// // //             onPress={() => navigation.navigate('Inventory')}
// // //           >
// // //             <Text style={styles.statValue}>{dashboardData.lowStockProducts}</Text>
// // //             <Text style={styles.statLabel}>Low Stock Items</Text>
// // //           </TouchableOpacity>
          
// // //           <TouchableOpacity 
// // //             style={[styles.statCard, styles.successCard]} 
// // //             onPress={() => navigation.navigate('Sales')}
// // //           >
// // //             <Text style={styles.statValue}>{formatCurrency(dashboardData.totalSales)}</Text>
// // //             <Text style={styles.statLabel}>Total Sales</Text>
// // //           </TouchableOpacity>
// // //         </View>
        
// // //         <View style={styles.sectionContainer}>
// // //           <Text style={styles.sectionTitle}>Recent Sales</Text>
// // //           {dashboardData.recentSales.length > 0 ? (
// // //             dashboardData.recentSales.map((sale, index) => (
// // //               <TouchableOpacity 
// // //                 key={sale.id || index} 
// // //                 style={styles.listItem}
// // //                 onPress={() => navigation.navigate('SaleDetails', { saleId: sale.id })}
// // //               >
// // //                 <View>
// // //                   <Text style={styles.listItemTitle}>Sale #{sale.id?.substring(0, 8) || index}</Text>
// // //                   <Text style={styles.listItemSubtitle}>{formatDate(sale.date)}</Text>
// // //                 </View>
// // //                 <Text style={styles.listItemAmount}>{formatCurrency(sale.totalAmount || 0)}</Text>
// // //               </TouchableOpacity>
// // //             ))
// // //           ) : (
// // //             <Text style={styles.emptyText}>No recent sales</Text>
// // //           )}
          
// // //           <TouchableOpacity 
// // //             style={styles.viewAllButton}
// // //             onPress={() => navigation.navigate('Sales')}
// // //           >
// // //             <Text style={styles.viewAllButtonText}>View All Sales</Text>
// // //           </TouchableOpacity>
// // //         </View>
        
// // //         <View style={styles.sectionContainer}>
// // //           <Text style={styles.sectionTitle}>Expiring Products</Text>
// // //           {dashboardData.expiringProducts.length > 0 ? (
// // //             dashboardData.expiringProducts.map((product, index) => (
// // //               <TouchableOpacity 
// // //                 key={product.id || index} 
// // //                 style={styles.listItem}
// // //                 onPress={() => navigation.navigate('EditProduct', { productId: product.id })}
// // //               >
// // //                 <View>
// // //                   <Text style={styles.listItemTitle}>{product.name}</Text>
// // //                   <Text style={styles.listItemSubtitle}>Expires: {formatDate(product.expiryDate)}</Text>
// // //                 </View>
// // //                 <Text style={[styles.expiryTag, 
// // //                   product.expiryDate && product.expiryDate < new Date() 
// // //                     ? styles.expiredTag 
// // //                     : styles.expiringTag
// // //                 ]}>
// // //                   {product.expiryDate && product.expiryDate < new Date() ? 'Expired' : 'Expiring Soon'}
// // //                 </Text>
// // //               </TouchableOpacity>
// // //             ))
// // //           ) : (
// // //             <Text style={styles.emptyText}>No products expiring soon</Text>
// // //           )}
          
// // //           <TouchableOpacity 
// // //             style={styles.viewAllButton}
// // //             onPress={() => navigation.navigate('Inventory')}
// // //           >
// // //             <Text style={styles.viewAllButtonText}>View All Products</Text>
// // //           </TouchableOpacity>
// // //         </View>
// // //       </ScrollView>
// // //     </View>
// // //   );
// // // };

// // // const styles = StyleSheet.create({
// // //   container: {
// // //     flex: 1,
// // //     backgroundColor: '#f5f5f5',
// // //   },
// // //   loadingContainer: {
// // //     flex: 1,
// // //     justifyContent: 'center',
// // //     alignItems: 'center',
// // //   },
// // //   loadingText: {
// // //     marginTop: 10,
// // //     fontSize: 16,
// // //     color: '#4CAF50',
// // //   },
// // //   header: {
// // //     backgroundColor: '#4CAF50',
// // //     padding: 15,
// // //     flexDirection: 'row',
// // //     justifyContent: 'space-between',
// // //     alignItems: 'center',
// // //   },
// // //   headerTitle: {
// // //     color: '#fff',
// // //     fontSize: 20,
// // //     fontWeight: 'bold',
// // //   },
// // //   content: {
// // //     flex: 1,
// // //     padding: 15,
// // //   },
// // //   statsContainer: {
// // //     flexDirection: 'row',
// // //     justifyContent: 'space-between',
// // //     marginBottom: 20,
// // //   },
// // //   statCard: {
// // //     backgroundColor: '#fff',
// // //     borderRadius: 8,
// // //     padding: 15,
// // //     width: '31%',
// // //     alignItems: 'center',
// // //     shadowColor: '#000',
// // //     shadowOffset: { width: 0, height: 1 },
// // //     shadowOpacity: 0.2,
// // //     shadowRadius: 1.41,
// // //     elevation: 2,
// // //   },
// // //   warningCard: {
// // //     backgroundColor: '#FFF3E0',
// // //   },
// // //   successCard: {
// // //     backgroundColor: '#E8F5E9',
// // //   },
// // //   statValue: {
// // //     fontSize: 20,
// // //     fontWeight: 'bold',
// // //     marginBottom: 5,
// // //   },
// // //   statLabel: {
// // //     fontSize: 12,
// // //     color: '#757575',
// // //     textAlign: 'center',
// // //   },
// // //   sectionContainer: {
// // //     backgroundColor: '#fff',
// // //     borderRadius: 8,
// // //     padding: 15,
// // //     marginBottom: 20,
// // //     shadowColor: '#000',
// // //     shadowOffset: { width: 0, height: 1 },
// // //     shadowOpacity: 0.2,
// // //     shadowRadius: 1.41,
// // //     elevation: 2,
// // //   },
// // //   sectionTitle: {
// // //     fontSize: 18,
// // //     fontWeight: 'bold',
// // //     marginBottom: 15,
// // //   },
// // //   listItem: {
// // //     flexDirection: 'row',
// // //     justifyContent: 'space-between',
// // //     alignItems: 'center',
// // //     paddingVertical: 12,
// // //     borderBottomWidth: 1,
// // //     borderBottomColor: '#f0f0f0',
// // //   },
// // //   listItemTitle: {
// // //     fontSize: 16,
// // //     fontWeight: '500',
// // //   },
// // //   listItemSubtitle: {
// // //     fontSize: 14,
// // //     color: '#757575',
// // //     marginTop: 2,
// // //   },
// // //   listItemAmount: {
// // //     fontSize: 16,
// // //     fontWeight: 'bold',
// // //     color: '#4CAF50',
// // //   },
// // //   expiryTag: {
// // //     paddingHorizontal: 10,
// // //     paddingVertical: 5,
// // //     borderRadius: 4,
// // //     fontSize: 12,
// // //     fontWeight: 'bold',
// // //   },
// // //   expiringTag: {
// // //     backgroundColor: '#FFF3E0',
// // //     color: '#FF9800',
// // //   },
// // //   expiredTag: {
// // //     backgroundColor: '#FFEBEE',
// // //     color: '#F44336',
// // //   },
// // //   emptyText: {
// // //     textAlign: 'center',
// // //     color: '#757575',
// // //     padding: 15,
// // //   },
// // //   viewAllButton: {
// // //     marginTop: 15,
// // //     padding: 10,
// // //     backgroundColor: '#E8F5E9',
// // //     borderRadius: 4,
// // //     alignItems: 'center',
// // //   },
// // //   viewAllButtonText: {
// // //     color: '#4CAF50',
// // //     fontWeight: '500',
// // //   },
// // // });

// // // export default Dashboard;

// // import React, { useState, useEffect } from 'react';
// // import { View, Text, StyleSheet, TouchableOpacity, ScrollView, ActivityIndicator } from 'react-native';
// // import { collection, getDocs, query, where, orderBy, limit } from 'firebase/firestore';
// // import { db } from '../firebaseConfig';
// // import Icon from 'react-native-vector-icons/MaterialIcons';

// // const Dashboard = ({ navigation }) => {
// //   const [loading, setLoading] = useState(true);
// //   const [dashboardData, setDashboardData] = useState({
// //     totalProducts: 0,
// //     lowStockProducts: 0,
// //     totalSales: 0,
// //     recentSales: [],
// //     expiringProducts: []
// //   });

// //   useEffect(() => {
// //     const fetchDashboardData = async () => {
// //       try {
// //         setLoading(true);
        
// //         // Get total products
// //         const productsSnapshot = await getDocs(collection(db, 'products'));
// //         const totalProducts = productsSnapshot.size;
        
// //         // Get low stock products
// //         const lowStockQuery = query(
// //           collection(db, 'products'),
// //           where('quantity', '<', 10)
// //         );
// //         const lowStockSnapshot = await getDocs(lowStockQuery);
// //         const lowStockProducts = lowStockSnapshot.size;
        
// //         // Get total sales
// //         const salesSnapshot = await getDocs(collection(db, 'sales'));
// //         let totalSales = 0;
// //         salesSnapshot.forEach(doc => {
// //           const saleData = doc.data();
// //           totalSales += saleData.totalAmount || 0;
// //         });
        
// //         // Get recent sales
// //         const recentSalesQuery = query(
// //           collection(db, 'sales'),
// //           orderBy('date', 'desc'),
// //           limit(5)
// //         );
// //         const recentSalesSnapshot = await getDocs(recentSalesQuery);
// //         const recentSales = recentSalesSnapshot.docs.map(doc => {
// //           const data = doc.data();
// //           // Safely handle date conversion
// //           const date = data.date && typeof data.date.toDate === 'function' 
// //             ? data.date.toDate() 
// //             : new Date();
          
// //           return {
// //             id: doc.id,
// //             ...data,
// //             date: date
// //           };
// //         });
        
// //         // Get expiring products
// //         const today = new Date();
// //         const threeMonthsLater = new Date();
// //         threeMonthsLater.setMonth(today.getMonth() + 3);
        
// //         const expiringProductsQuery = query(
// //           collection(db, 'products'),
// //           where('expiryDate', '<=', threeMonthsLater)
// //         );
        
// //         const expiringProductsSnapshot = await getDocs(expiringProductsQuery);
// //         const expiringProducts = expiringProductsSnapshot.docs.map(doc => {
// //           const data = doc.data();
// //           // Safely handle date conversion
// //           const expiryDate = data.expiryDate && typeof data.expiryDate.toDate === 'function'
// //             ? data.expiryDate.toDate()
// //             : null;
          
// //           return {
// //             id: doc.id,
// //             ...data,
// //             expiryDate: expiryDate
// //           };
// //         }).filter(product => product.expiryDate !== null);
        
// //         setDashboardData({
// //           totalProducts,
// //           lowStockProducts,
// //           totalSales,
// //           recentSales,
// //           expiringProducts
// //         });
        
// //       } catch (error) {
// //         console.error("Error fetching dashboard data:", error);
// //       } finally {
// //         setLoading(false);
// //       }
// //     };

// //     fetchDashboardData();
// //   }, []);

// //   const formatDate = (date) => {
// //     if (!date) return 'N/A';
// //     return `${date.getDate()}/${date.getMonth() + 1}/${date.getFullYear()}`;
// //   };

// //   const formatCurrency = (amount) => {
// //     return `$${parseFloat(amount).toFixed(2)}`;
// //   };

// //   // This is the key change - use openDrawer instead of toggleDrawer
// //   const handleMenuPress = () => {
// //     if (navigation.openDrawer) {
// //       navigation.openDrawer();
// //     } else {
// //       console.warn('Drawer navigation is not available');
// //     }
// //   };

// //   if (loading) {
// //     return (
// //       <View style={styles.loadingContainer}>
// //         <ActivityIndicator size="large" color="#4CAF50" />
// //         <Text style={styles.loadingText}>Loading dashboard data...</Text>
// //       </View>
// //     );
// //   }

// //   return (
// //     <View style={styles.container}>
// //       <View style={styles.header}>
// //         <Text style={styles.headerTitle}>Dashboard</Text>
// //         <TouchableOpacity onPress={handleMenuPress}>
// //           <Icon name="menu" size={24} color="#fff" />
// //         </TouchableOpacity>
// //       </View>
      
// //       <ScrollView style={styles.content}>
// //         <View style={styles.statsContainer}>
// //           <TouchableOpacity 
// //             style={styles.statCard} 
// //             onPress={() => navigation.navigate('Inventory')}
// //           >
// //             <Text style={styles.statValue}>{dashboardData.totalProducts}</Text>
// //             <Text style={styles.statLabel}>Total Products</Text>
// //           </TouchableOpacity>
          
// //           <TouchableOpacity 
// //             style={[styles.statCard, styles.warningCard]} 
// //             onPress={() => navigation.navigate('Inventory')}
// //           >
// //             <Text style={styles.statValue}>{dashboardData.lowStockProducts}</Text>
// //             <Text style={styles.statLabel}>Low Stock Items</Text>
// //           </TouchableOpacity>
          
// //           <TouchableOpacity 
// //             style={[styles.statCard, styles.successCard]} 
// //             onPress={() => navigation.navigate('Sales')}
// //           >
// //             <Text style={styles.statValue}>{formatCurrency(dashboardData.totalSales)}</Text>
// //             <Text style={styles.statLabel}>Total Sales</Text>
// //           </TouchableOpacity>
// //         </View>
        
// //         <View style={styles.sectionContainer}>
// //           <Text style={styles.sectionTitle}>Recent Sales</Text>
// //           {dashboardData.recentSales.length > 0 ? (
// //             dashboardData.recentSales.map((sale, index) => (
// //               <TouchableOpacity 
// //                 key={sale.id || index} 
// //                 style={styles.listItem}
// //                 onPress={() => navigation.navigate('SaleDetails', { saleId: sale.id })}
// //               >
// //                 <View>
// //                   <Text style={styles.listItemTitle}>Sale #{sale.id?.substring(0, 8) || index}</Text>
// //                   <Text style={styles.listItemSubtitle}>{formatDate(sale.date)}</Text>
// //                 </View>
// //                 <Text style={styles.listItemAmount}>{formatCurrency(sale.totalAmount || 0)}</Text>
// //               </TouchableOpacity>
// //             ))
// //           ) : (
// //             <Text style={styles.emptyText}>No recent sales</Text>
// //           )}
          
// //           <TouchableOpacity 
// //             style={styles.viewAllButton}
// //             onPress={() => navigation.navigate('Sales')}
// //           >
// //             <Text style={styles.viewAllButtonText}>View All Sales</Text>
// //           </TouchableOpacity>
// //         </View>
        
// //         <View style={styles.sectionContainer}>
// //           <Text style={styles.sectionTitle}>Expiring Products</Text>
// //           {dashboardData.expiringProducts.length > 0 ? (
// //             dashboardData.expiringProducts.map((product, index) => (
// //               <TouchableOpacity 
// //                 key={product.id || index} 
// //                 style={styles.listItem}
// //                 onPress={() => navigation.navigate('EditProduct', { productId: product.id })}
// //               >
// //                 <View>
// //                   <Text style={styles.listItemTitle}>{product.name}</Text>
// //                   <Text style={styles.listItemSubtitle}>Expires: {formatDate(product.expiryDate)}</Text>
// //                 </View>
// //                 <Text style={[styles.expiryTag, 
// //                   product.expiryDate && product.expiryDate < new Date() 
// //                     ? styles.expiredTag 
// //                     : styles.expiringTag
// //                 ]}>
// //                   {product.expiryDate && product.expiryDate < new Date() ? 'Expired' : 'Expiring Soon'}
// //                 </Text>
// //               </TouchableOpacity>
// //             ))
// //           ) : (
// //             <Text style={styles.emptyText}>No products expiring soon</Text>
// //           )}
          
// //           <TouchableOpacity 
// //             style={styles.viewAllButton}
// //             onPress={() => navigation.navigate('Inventory')}
// //           >
// //             <Text style={styles.viewAllButtonText}>View All Products</Text>
// //           </TouchableOpacity>
// //         </View>
// //       </ScrollView>
// //     </View>
// //   );
// // };

// // const styles = StyleSheet.create({
// //   container: {
// //     flex: 1,
// //     backgroundColor: '#f5f5f5',
// //   },
// //   loadingContainer: {
// //     flex: 1,
// //     justifyContent: 'center',
// //     alignItems: 'center',
// //   },
// //   loadingText: {
// //     marginTop: 10,
// //     fontSize: 16,
// //     color: '#4CAF50',
// //   },
// //   header: {
// //     backgroundColor: '#4CAF50',
// //     padding: 15,
// //     flexDirection: 'row',
// //     justifyContent: 'space-between',
// //     alignItems: 'center',
// //   },
// //   headerTitle: {
// //     color: '#fff',
// //     fontSize: 20,
// //     fontWeight: 'bold',
// //   },
// //   content: {
// //     flex: 1,
// //     padding: 15,
// //   },
// //   statsContainer: {
// //     flexDirection: 'row',
// //     justifyContent: 'space-between',
// //     marginBottom: 20,
// //   },
// //   statCard: {
// //     backgroundColor: '#fff',
// //     borderRadius: 8,
// //     padding: 15,
// //     width: '31%',
// //     alignItems: 'center',
// //     shadowColor: '#000',
// //     shadowOffset: { width: 0, height: 1 },
// //     shadowOpacity: 0.2,
// //     shadowRadius: 1.41,
// //     elevation: 2,
// //   },
// //   warningCard: {
// //     backgroundColor: '#FFF3E0',
// //   },
// //   successCard: {
// //     backgroundColor: '#E8F5E9',
// //   },
// //   statValue: {
// //     fontSize: 20,
// //     fontWeight: 'bold',
// //     marginBottom: 5,
// //   },
// //   statLabel: {
// //     fontSize: 12,
// //     color: '#757575',
// //     textAlign: 'center',
// //   },
// //   sectionContainer: {
// //     backgroundColor: '#fff',
// //     borderRadius: 8,
// //     padding: 15,
// //     marginBottom: 20,
// //     shadowColor: '#000',
// //     shadowOffset: { width: 0, height: 1 },
// //     shadowOpacity: 0.2,
// //     shadowRadius: 1.41,
// //     elevation: 2,
// //   },
// //   sectionTitle: {
// //     fontSize: 18,
// //     fontWeight: 'bold',
// //     marginBottom: 15,
// //   },
// //   listItem: {
// //     flexDirection: 'row',
// //     justifyContent: 'space-between',
// //     alignItems: 'center',
// //     paddingVertical: 12,
// //     borderBottomWidth: 1,
// //     borderBottomColor: '#f0f0f0',
// //   },
// //   listItemTitle: {
// //     fontSize: 16,
// //     fontWeight: '500',
// //   },
// //   listItemSubtitle: {
// //     fontSize: 14,
// //     color: '#757575',
// //     marginTop: 2,
// //   },
// //   listItemAmount: {
// //     fontSize: 16,
// //     fontWeight: 'bold',
// //     color: '#4CAF50',
// //   },
// //   expiryTag: {
// //     paddingHorizontal: 10,
// //     paddingVertical: 5,
// //     borderRadius: 4,
// //     fontSize: 12,
// //     fontWeight: 'bold',
// //   },
// //   expiringTag: {
// //     backgroundColor: '#FFF3E0',
// //     color: '#FF9800',
// //   },
// //   expiredTag: {
// //     backgroundColor: '#FFEBEE',
// //     color: '#F44336',
// //   },
// //   emptyText: {
// //     textAlign: 'center',
// //     color: '#757575',
// //     padding: 15,
// //   },
// //   viewAllButton: {
// //     marginTop: 15,
// //     padding: 10,
// //     backgroundColor: '#E8F5E9',
// //     borderRadius: 4,
// //     alignItems: 'center',
// //   },
// //   viewAllButtonText: {
// //     color: '#4CAF50',
// //     fontWeight: '500',
// //   },
// // });

// // export default Dashboard;


// import React, { useState, useEffect } from 'react';
// import { View, Text, StyleSheet, TouchableOpacity, ScrollView, ActivityIndicator } from 'react-native';
// import { collection, getDocs, query, where, orderBy, limit } from 'firebase/firestore';
// import { db } from '../firebaseConfig';
// import Icon from 'react-native-vector-icons/MaterialIcons';

// const Dashboard = ({ navigation }) => {
//   const [loading, setLoading] = useState(true);
//   const [dashboardData, setDashboardData] = useState({
//     totalProducts: 0,
//     lowStockProducts: 0,
//     totalSales: 0,
//     recentSales: [],
//     expiringProducts: []
//   });

//   useEffect(() => {
//     const fetchDashboardData = async () => {
//       try {
//         setLoading(true);
        
//         // Get total products
//         const productsSnapshot = await getDocs(collection(db, 'products'));
//         const totalProducts = productsSnapshot.size;
        
//         // Get low stock products
//         const lowStockQuery = query(
//           collection(db, 'products'),
//           where('quantity', '<', 10)
//         );
//         const lowStockSnapshot = await getDocs(lowStockQuery);
//         const lowStockProducts = lowStockSnapshot.size;
        
//         // Get total sales
//         const salesSnapshot = await getDocs(collection(db, 'sales'));
//         let totalSales = 0;
//         salesSnapshot.forEach(doc => {
//           const saleData = doc.data();
//           totalSales += saleData.totalAmount || 0;
//         });
        
//         // Get recent sales
//         const recentSalesQuery = query(
//           collection(db, 'sales'),
//           orderBy('date', 'desc'),
//           limit(5)
//         );
//         const recentSalesSnapshot = await getDocs(recentSalesQuery);
//         const recentSales = recentSalesSnapshot.docs.map(doc => {
//           const data = doc.data();
//           // Safely handle date conversion
//           const date = data.date && typeof data.date.toDate === 'function' 
//             ? data.date.toDate() 
//             : new Date();
          
//           return {
//             id: doc.id,
//             ...data,
//             date: date
//           };
//         });
        
//         // Get expiring products
//         const today = new Date();
//         const threeMonthsLater = new Date();
//         threeMonthsLater.setMonth(today.getMonth() + 3);
        
//         const expiringProductsQuery = query(
//           collection(db, 'products'),
//           where('expiryDate', '<=', threeMonthsLater)
//         );
        
//         const expiringProductsSnapshot = await getDocs(expiringProductsQuery);
//         const expiringProducts = expiringProductsSnapshot.docs.map(doc => {
//           const data = doc.data();
//           // Safely handle date conversion
//           const expiryDate = data.expiryDate && typeof data.expiryDate.toDate === 'function'
//             ? data.expiryDate.toDate()
//             : null;
          
//           return {
//             id: doc.id,
//             ...data,
//             expiryDate: expiryDate
//           };
//         }).filter(product => product.expiryDate !== null);
        
//         setDashboardData({
//           totalProducts,
//           lowStockProducts,
//           totalSales,
//           recentSales,
//           expiringProducts
//         });
        
//       } catch (error) {
//         console.error("Error fetching dashboard data:", error);
//       } finally {
//         setLoading(false);
//       }
//     };

//     fetchDashboardData();
//   }, []);

//   const formatDate = (date) => {
//     if (!date) return 'N/A';
//     return `${date.getDate()}/${date.getMonth() + 1}/${date.getFullYear()}`;
//   };

//   const formatCurrency = (amount) => {
//     return `$${parseFloat(amount).toFixed(2)}`;
//   };

//   // This is the key change - use openDrawer instead of toggleDrawer
//   const handleMenuPress = () => {
//     navigation.openDrawer();
//   };

//   if (loading) {
//     return (
//       <View style={styles.loadingContainer}>
//         <ActivityIndicator size="large" color="#4CAF50" />
//         <Text style={styles.loadingText}>Loading dashboard...</Text>
//       </View>
//     );
//   }

//   return (
//     <View style={styles.container}>
//       <View style={styles.header}>
//         <Text style={styles.headerTitle}>Dashboard</Text>
//         <TouchableOpacity onPress={handleMenuPress}>
//           <Icon name="menu" size={24} color="#fff" />
//         </TouchableOpacity>
//       </View>
      
//       <ScrollView style={styles.content}>
//         <View style={styles.statsContainer}>
//           <TouchableOpacity 
//             style={styles.statCard} 
//             onPress={() => navigation.navigate('Inventory')}
//           >
//             <Text style={styles.statValue}>{dashboardData.totalProducts}</Text>
//             <Text style={styles.statLabel}>Total Products</Text>
//           </TouchableOpacity>
          
//           <TouchableOpacity 
//             style={[styles.statCard, styles.warningCard]} 
//             onPress={() => navigation.navigate('Inventory')}
//           >
//             <Text style={styles.statValue}>{dashboardData.lowStockProducts}</Text>
//             <Text style={styles.statLabel}>Low Stock Items</Text>
//           </TouchableOpacity>
          
//           <TouchableOpacity 
//             style={[styles.statCard, styles.successCard]} 
//             onPress={() => navigation.navigate('Sales')}
//           >
//             <Text style={styles.statValue}>{formatCurrency(dashboardData.totalSales)}</Text>
//             <Text style={styles.statLabel}>Total Sales</Text>
//           </TouchableOpacity>
//         </View>
        
//         <View style={styles.sectionContainer}>
//           <Text style={styles.sectionTitle}>Recent Sales</Text>
//           {dashboardData.recentSales.length > 0 ? (
//             dashboardData.recentSales.map((sale, index) => (
//               <TouchableOpacity 
//                 key={sale.id || index} 
//                 style={styles.listItem}
//                 onPress={() => navigation.navigate('SaleDetails', { saleId: sale.id })}
//               >
//                 <View>
//                   <Text style={styles.listItemTitle}>Sale #{sale.id?.substring(0, 8) || index}</Text>
//                   <Text style={styles.listItemSubtitle}>{formatDate(sale.date)}</Text>
//                 </View>
//                 <Text style={styles.listItemAmount}>{formatCurrency(sale.totalAmount || 0)}</Text>
//               </TouchableOpacity>
//             ))
//           ) : (
//             <Text style={styles.emptyText}>No recent sales</Text>
//           )}
          
//           <TouchableOpacity 
//             style={styles.viewAllButton}
//             onPress={() => navigation.navigate('Sales')}
//           >
//             <Text style={styles.viewAllButtonText}>View All Sales</Text>
//           </TouchableOpacity>
//         </View>
        
//         <View style={styles.sectionContainer}>
//           <Text style={styles.sectionTitle}>Expiring Products</Text>
//           {dashboardData.expiringProducts.length > 0 ? (
//             dashboardData.expiringProducts.map((product, index) => (
//               <TouchableOpacity 
//                 key={product.id || index} 
//                 style={styles.listItem}
//                 onPress={() => navigation.navigate('EditProduct', { productId: product.id })}
//               >
//                 <View>
//                   <Text style={styles.listItemTitle}>{product.name}</Text>
//                   <Text style={styles.listItemSubtitle}>Expires: {formatDate(product.expiryDate)}</Text>
//                 </View>
//                 <Text style={[styles.expiryTag, 
//                   product.expiryDate && product.expiryDate < new Date() 
//                     ? styles.expiredTag 
//                     : styles.expiringTag
//                 ]}>
//                   {product.expiryDate && product.expiryDate < new Date() ? 'Expired' : 'Expiring Soon'}
//                 </Text>
//               </TouchableOpacity>
//             ))
//           ) : (
//             <Text style={styles.emptyText}>No products expiring soon</Text>
//           )}
          
//           <TouchableOpacity 
//             style={styles.viewAllButton}
//             onPress={() => navigation.navigate('Inventory')}
//           >
//             <Text style={styles.viewAllButtonText}>View All Products</Text>
//           </TouchableOpacity>
//         </View>
//       </ScrollView>
//     </View>
//   );
// };

// const styles = StyleSheet.create({
//   container: {
//     flex: 1,
//     backgroundColor: '#f5f5f5',
//   },
//   loadingContainer: {
//     flex: 1,
//     justifyContent: 'center',
//     alignItems: 'center',
//   },
//   loadingText: {
//     marginTop: 10,
//     fontSize: 16,
//     color: '#4CAF50',
//   },
//   header: {
//     backgroundColor: '#4CAF50',
//     padding: 15,
//     flexDirection: 'row',
//     justifyContent: 'space-between',
//     alignItems: 'center',
//   },
//   headerTitle: {
//     color: '#fff',
//     fontSize: 20,
//     fontWeight: 'bold',
//   },
//   content: {
//     flex: 1,
//     padding: 15,
//   },
//   statsContainer: {
//     flexDirection: 'row',
//     justifyContent: 'space-between',
//     marginBottom: 20,
//   },
//   statCard: {
//     backgroundColor: '#fff',
//     borderRadius: 8,
//     padding: 15,
//     width: '31%',
//     alignItems: 'center',
//     shadowColor: '#000',
//     shadowOffset: { width: 0, height: 1 },
//     shadowOpacity: 0.2,
//     shadowRadius: 1.41,
//     elevation: 2,
//   },
//   warningCard: {
//     backgroundColor: '#FFF3E0',
//   },
//   successCard: {
//     backgroundColor: '#E8F5E9',
//   },
//   statValue: {
//     fontSize: 20,
//     fontWeight: 'bold',
//     marginBottom: 5,
//   },
//   statLabel: {
//     fontSize: 12,
//     color: '#757575',
//     textAlign: 'center',
//   },
//   sectionContainer: {
//     backgroundColor: '#fff',
//     borderRadius: 8,
//     padding: 15,
//     marginBottom: 20,
//     shadowColor: '#000',
//     shadowOffset: { width: 0, height: 1 },
//     shadowOpacity: 0.2,
//     shadowRadius: 1.41,
//     elevation: 2,
//   },
//   sectionTitle: {
//     fontSize: 18,
//     fontWeight: 'bold',
//     marginBottom: 15,
//   },
//   listItem: {
//     flexDirection: 'row',
//     justifyContent: 'space-between',
//     alignItems: 'center',
//     paddingVertical: 12,
//     borderBottomWidth: 1,
//     borderBottomColor: '#f0f0f0',
//   },
//   listItemTitle: {
//     fontSize: 16,
//     fontWeight: '500',
//   },
//   listItemSubtitle: {
//     fontSize: 14,
//     color: '#757575',
//     marginTop: 2,
//   },
//   listItemAmount: {
//     fontSize: 16,
//     fontWeight: 'bold',
//     color: '#4CAF50',
//   },
//   expiryTag: {
//     paddingHorizontal: 10,
//     paddingVertical: 5,
//     borderRadius: 4,
//     fontSize: 12,
//     fontWeight: 'bold',
//   },
//   expiringTag: {
//     backgroundColor: '#FFF3E0',
//     color: '#FF9800',
//   },
//   expiredTag: {
//     backgroundColor: '#FFEBEE',
//     color: '#F44336',
//   },
//   emptyText: {
//     textAlign: 'center',
//     color: '#757575',
//     padding: 15,
//   },
//   viewAllButton: {
//     marginTop: 15,
//     padding: 10,
//     backgroundColor: '#E8F5E9',
//     borderRadius: 4,
//     alignItems: 'center',
//   },
//   viewAllButtonText: {
//     color: '#4CAF50',
//     fontWeight: '500',
//   },
// });

// export default Dashboard;

"use client"

import { useState, useCallback } from "react"
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  ActivityIndicator,
  RefreshControl,
  Alert,
  Dimensions,
} from "react-native"
import { Ionicons } from "@expo/vector-icons"
import { auth, db } from "../firebaseConfig"
import { collection, getDocs, query, orderBy, limit, where } from "firebase/firestore"
import { useFocusEffect } from "@react-navigation/native"
import { LineChart } from "react-native-chart-kit"

const screenWidth = Dimensions.get("window").width

const Dashboard = ({ navigation }) => {
  const [loading, setLoading] = useState(true)
  const [refreshing, setRefreshing] = useState(false)
  const [dashboardData, setDashboardData] = useState({
    totalSales: 0,
    totalProducts: 0,
    lowStockProducts: 0,
    recentSales: [],
    topSellingProducts: [],
    salesData: {
      labels: ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"],
      datasets: [
        {
          data: [0, 0, 0, 0, 0, 0, 0],
        },
      ],
    },
  })

  // Function to fetch dashboard data
  const fetchDashboardData = useCallback(async () => {
    try {
      console.log("Fetching dashboard data...")
      setLoading(true)

      // Create an object to store all promises
      const promises = {}

      // Get total products count
      promises.productsCount = getDocs(collection(db, "products")).then((snapshot) => snapshot.size)

      // Get low stock products count
      promises.lowStockCount = getDocs(query(collection(db, "products"), where("quantity", "<", 10))).then(
        (snapshot) => snapshot.size,
      )

      // Get recent sales
      promises.recentSales = getDocs(query(collection(db, "sales"), orderBy("date", "desc"), limit(5))).then(
        (snapshot) =>
          snapshot.docs.map((doc) => ({
            id: doc.id,
            ...doc.data(),
            date: doc.data().date?.toDate?.() || new Date(),
          })),
      )

      // Get total sales amount
      promises.salesTotal = getDocs(collection(db, "sales")).then((snapshot) => {
        return snapshot.docs.reduce((total, doc) => {
          return total + (doc.data().totalAmount || 0)
        }, 0)
      })

      // Get top selling products
      promises.topProducts = getDocs(query(collection(db, "products"), orderBy("soldCount", "desc"), limit(5))).then(
        (snapshot) =>
          snapshot.docs.map((doc) => ({
            id: doc.id,
            ...doc.data(),
          })),
      )

      // Get sales data for chart (last 7 days)
      promises.salesChart = getDocs(
        query(
          collection(db, "sales"),
          where("date", ">=", new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)),
          orderBy("date", "asc"),
        ),
      ).then((snapshot) => {
        // Initialize data for the last 7 days
        const last7Days = Array(7).fill(0)
        const dayLabels = []

        // Get day labels (Mon, Tue, etc.)
        for (let i = 6; i >= 0; i--) {
          const date = new Date()
          date.setDate(date.getDate() - i)
          dayLabels.unshift(date.toLocaleDateString("en-US", { weekday: "short" }))
        }

        // Fill in sales data
        snapshot.docs.forEach((doc) => {
          const saleDate = doc.data().date?.toDate() || new Date(doc.data().date)
          const dayIndex = 6 - Math.floor((Date.now() - saleDate.getTime()) / (24 * 60 * 60 * 1000))

          if (dayIndex >= 0 && dayIndex < 7) {
            last7Days[dayIndex] += doc.data().totalAmount || 0
          }
        })

        return {
          labels: dayLabels,
          datasets: [{ data: last7Days }],
        }
      })

      // Resolve all promises concurrently
      const [productsCount, lowStockCount, recentSales, salesTotal, topProducts, salesChart] = await Promise.all([
        promises.productsCount,
        promises.lowStockCount,
        promises.recentSales,
        promises.salesTotal,
        promises.topProducts,
        promises.salesChart,
      ])

      console.log("Dashboard data fetched successfully")

      setDashboardData({
        totalProducts: productsCount,
        lowStockProducts: lowStockCount,
        recentSales: recentSales,
        totalSales: salesTotal,
        topSellingProducts: topProducts,
        salesData: salesChart,
      })
    } catch (error) {
      console.error("Error fetching dashboard data:", error)
      Alert.alert("Error", "Failed to load dashboard data")
    } finally {
      setLoading(false)
      setRefreshing(false)
    }
  }, [])

  // Fetch data when screen comes into focus
  useFocusEffect(
    useCallback(() => {
      fetchDashboardData()

      return () => {
        // Cleanup if needed
      }
    }, [fetchDashboardData]),
  )

  const onRefresh = useCallback(() => {
    setRefreshing(true)
    fetchDashboardData()
  }, [fetchDashboardData])

  if (loading && !refreshing) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#5C6BC0" />
        <Text style={styles.loadingText}>Loading dashboard...</Text>
      </View>
    )
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.openDrawer()}>
          <Ionicons name="menu" size={28} color="#333" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Dashboard</Text>
        <TouchableOpacity onPress={() => auth.signOut().then(() => navigation.replace("Login"))}>
          <Ionicons name="log-out-outline" size={24} color="#333" />
        </TouchableOpacity>
      </View>

      <ScrollView
        style={styles.content}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
      >
        <View style={styles.statsContainer}>
          <View style={styles.statCard}>
            <Ionicons name="cash-outline" size={24} color="#5C6BC0" />
            <Text style={styles.statValue}>${dashboardData.totalSales.toFixed(2)}</Text>
            <Text style={styles.statLabel}>Total Sales</Text>
          </View>

          <View style={styles.statCard}>
            <Ionicons name="medical" size={24} color="#5C6BC0" />
            <Text style={styles.statValue}>{dashboardData.totalProducts}</Text>
            <Text style={styles.statLabel}>Products</Text>
          </View>

          <View style={styles.statCard}>
            <Ionicons
              name="alert-circle-outline"
              size={24}
              color={dashboardData.lowStockProducts > 0 ? "#FF5252" : "#5C6BC0"}
            />
            <Text style={[styles.statValue, dashboardData.lowStockProducts > 0 ? styles.alertText : {}]}>
              {dashboardData.lowStockProducts}
            </Text>
            <Text style={styles.statLabel}>Low Stock</Text>
          </View>
        </View>

        {/* Sales Chart */}
        <View style={styles.chartContainer}>
          <Text style={styles.sectionTitle}>Sales Last 7 Days</Text>
          <LineChart
            data={dashboardData.salesData}
            width={screenWidth - 40}
            height={220}
            chartConfig={{
              backgroundColor: "#ffffff",
              backgroundGradientFrom: "#ffffff",
              backgroundGradientTo: "#ffffff",
              decimalPlaces: 0,
              color: (opacity = 1) => `rgba(92, 107, 192, ${opacity})`,
              labelColor: (opacity = 1) => `rgba(0, 0, 0, ${opacity})`,
              style: {
                borderRadius: 16,
              },
              propsForDots: {
                r: "6",
                strokeWidth: "2",
                stroke: "#5C6BC0",
              },
            }}
            bezier
            style={{
              marginVertical: 8,
              borderRadius: 16,
            }}
          />
        </View>

        <View style={styles.sectionContainer}>
          <Text style={styles.sectionTitle}>Recent Sales</Text>
          {dashboardData.recentSales.length > 0 ? (
            dashboardData.recentSales.map((sale, index) => (
              <TouchableOpacity
                key={sale.id}
                style={styles.saleItem}
                onPress={() => navigation.navigate("SaleDetails", { saleId: sale.id })}
              >
                <View style={styles.saleInfo}>
                  <Text style={styles.saleCustomer}>{sale.customerName || "Walk-in Customer"}</Text>
                  <Text style={styles.saleDate}>
                    {sale.date instanceof Date
                      ? sale.date.toLocaleDateString()
                      : new Date(sale.date).toLocaleDateString()}
                  </Text>
                </View>
                <Text style={styles.saleAmount}>${sale.totalAmount?.toFixed(2) || "0.00"}</Text>
              </TouchableOpacity>
            ))
          ) : (
            <Text style={styles.emptyText}>No recent sales</Text>
          )}
          <TouchableOpacity style={styles.viewAllButton} onPress={() => navigation.navigate("Sales")}>
            <Text style={styles.viewAllText}>View All Sales</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.sectionContainer}>
          <Text style={styles.sectionTitle}>Top Selling Products</Text>
          {dashboardData.topSellingProducts.length > 0 ? (
            dashboardData.topSellingProducts.map((product, index) => (
              <View key={product.id} style={styles.productItem}>
                <View style={styles.productRank}>
                  <Text style={styles.rankText}>{index + 1}</Text>
                </View>
                <View style={styles.productInfo}>
                  <Text style={styles.productName}>{product.name}</Text>
                  <Text style={styles.productCategory}>{product.category}</Text>
                </View>
                <Text style={styles.productSold}>{product.soldCount || 0} sold</Text>
              </View>
            ))
          ) : (
            <Text style={styles.emptyText}>No sales data available</Text>
          )}
          <TouchableOpacity style={styles.viewAllButton} onPress={() => navigation.navigate("Inventory")}>
            <Text style={styles.viewAllText}>View Inventory</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.quickActions}>
          <Text style={styles.sectionTitle}>Quick Actions</Text>
          <View style={styles.actionButtons}>
            <TouchableOpacity style={styles.actionButton} onPress={() => navigation.navigate("NewSale")}>
              <Ionicons name="cart" size={24} color="#fff" />
              <Text style={styles.actionText}>New Sale</Text>
            </TouchableOpacity>

            <TouchableOpacity style={styles.actionButton} onPress={() => navigation.navigate("AddProduct")}>
              <Ionicons name="add-circle" size={24} color="#fff" />
              <Text style={styles.actionText}>Add Product</Text>
            </TouchableOpacity>

            <TouchableOpacity style={styles.actionButton} onPress={() => navigation.navigate("Reports")}>
              <Ionicons name="bar-chart" size={24} color="#fff" />
              <Text style={styles.actionText}>Reports</Text>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f5f5f5",
  },
  loadingContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#f5f5f5",
  },
  loadingText: {
    marginTop: 10,
    fontSize: 16,
    color: "#5C6BC0",
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingHorizontal: 16,
    paddingTop: 50,
    paddingBottom: 16,
    backgroundColor: "#fff",
    elevation: 2,
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: "bold",
    color: "#333",
  },
  content: {
    flex: 1,
  },
  statsContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    padding: 16,
  },
  statCard: {
    backgroundColor: "#fff",
    borderRadius: 8,
    padding: 16,
    alignItems: "center",
    width: "30%",
    elevation: 2,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.2,
    shadowRadius: 1.41,
  },
  statValue: {
    fontSize: 18,
    fontWeight: "bold",
    marginVertical: 8,
    color: "#333",
  },
  statLabel: {
    fontSize: 12,
    color: "#666",
  },
  alertText: {
    color: "#FF5252",
  },
  chartContainer: {
    backgroundColor: "#fff",
    borderRadius: 8,
    margin: 16,
    marginTop: 0,
    padding: 16,
    elevation: 2,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.2,
    shadowRadius: 1.41,
  },
  sectionContainer: {
    backgroundColor: "#fff",
    borderRadius: 8,
    margin: 16,
    marginTop: 0,
    padding: 16,
    elevation: 2,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.2,
    shadowRadius: 1.41,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: "bold",
    marginBottom: 16,
    color: "#333",
  },
  saleItem: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: "#eee",
  },
  saleInfo: {
    flex: 1,
  },
  saleCustomer: {
    fontSize: 16,
    color: "#333",
  },
  saleDate: {
    fontSize: 12,
    color: "#666",
    marginTop: 4,
  },
  saleAmount: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#5C6BC0",
  },
  productItem: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: "#eee",
  },
  productRank: {
    width: 30,
    height: 30,
    borderRadius: 15,
    backgroundColor: "#5C6BC0",
    justifyContent: "center",
    alignItems: "center",
    marginRight: 12,
  },
  rankText: {
    color: "#fff",
    fontWeight: "bold",
  },
  productInfo: {
    flex: 1,
  },
  productName: {
    fontSize: 16,
    color: "#333",
  },
  productCategory: {
    fontSize: 12,
    color: "#666",
    marginTop: 4,
  },
  productSold: {
    fontSize: 14,
    fontWeight: "bold",
    color: "#5C6BC0",
  },
  emptyText: {
    textAlign: "center",
    color: "#666",
    padding: 16,
  },
  viewAllButton: {
    alignItems: "center",
    marginTop: 16,
    paddingVertical: 8,
    backgroundColor: "#f0f0f0",
    borderRadius: 4,
  },
  viewAllText: {
    color: "#5C6BC0",
    fontWeight: "bold",
  },
  quickActions: {
    margin: 16,
    marginTop: 0,
    marginBottom: 24,
  },
  actionButtons: {
    flexDirection: "row",
    justifyContent: "space-between",
  },
  actionButton: {
    backgroundColor: "#5C6BC0",
    borderRadius: 8,
    padding: 16,
    alignItems: "center",
    width: "30%",
    elevation: 2,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.2,
    shadowRadius: 1.41,
  },
  actionText: {
    color: "#fff",
    marginTop: 8,
    fontWeight: "bold",
  },
})

export default Dashboard

